package com.touchpilot

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class TouchService : Service() {
    private lateinit var windowManager: WindowManager
    private val groups = mutableListOf<Group>()
    private var selectedGroup = 0
    private var captureGroup = 0
    private var selectorRow: LinearLayout? = null
    private var panel: View? = null
    private var passThrough = false
    private var busy = false
    private var repeating = false
    private var pressMode = 0   // 0 = tap, 1 = long press, 2 = very fast repeat
    private var together = true // true = one multi-touch gesture, false = quick one-after-another
    private var logoView: View? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlaysHidden = false
    private val handler = Handler(Looper.getMainLooper())
    private val notificationId = 91

    // One group = one T button plus its own copies. Pressing a T taps only its own group.
    private class Group(var colorIdx: Int) {
        var tView: View? = null
        val views = mutableListOf<View>()
        val coords = mutableListOf<Pair<Float, Float>>()
    }

    private fun colorOf(g: Group) = GROUP_COLORS[g.colorIdx % GROUP_COLORS.size]

    private fun chipViews(): List<View> = groups.flatMap { listOfNotNull(it.tView) + it.views }

    private fun allOverlays(): List<View> = listOfNotNull(panel) + chipViews()

    private fun tSizePx() = dp(56)

    // Where the T of the n-th group starts (fractions of the screen).
    private fun defaultTPos(pos: Int): Pair<Float, Float> =
        if (pos == 0) 0.8f to 0.5f
        else (0.85f - 0.18f * (pos / 4)) to (0.25f + 0.17f * (pos % 4))

    private fun createGroup(nx: Float, ny: Float, colorIdx: Int): Group {
        val g = Group(colorIdx)
        groups.add(g)
        val pos = groups.size - 1
        val size = tSizePx()
        val button = TextView(this).apply {
            text = if (pos == 0) "T" else "T${pos + 1}"
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            minWidth = size; minHeight = size
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(colorOf(g)); setStroke(dp(2), Color.WHITE)
            }
        }
        val (screenW, screenH) = screenSize()
        g.tView = button
        button.alpha = if (overlaysHidden) 0f else 1f
        windowManager.addView(
            button,
            overlayParams(
                max(0, (nx * screenW - size / 2f).toInt()),
                max(0, (ny * screenH - size / 2f).toInt()),
                !overlaysHidden && !passThrough
            )
        )
        button.setOnTouchListener(dragListener(button, onDragEnd = { persistGroups() }) { onTPressed(g) })
        return g
    }

    private fun tCenter(g: Group): Pair<Float, Float>? {
        val v = g.tView ?: return null
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return null
        val w = if (v.width > 0) v.width else tSizePx()
        val h = if (v.height > 0) v.height else tSizePx()
        return (p.x + w / 2f) to (p.y + h / 2f)
    }

    private fun relabelAll() {
        groups.forEachIndexed { gi, g ->
            (g.tView as? TextView)?.text = if (gi == 0) "T" else "T${gi + 1}"
            g.views.forEachIndexed { k, v -> (v as? TextView)?.text = "${gi + 1}.${k + 1}" }
        }
    }

    // Row in the panel menu: pick which T the next actions apply to, or add a new T.
    private fun rebuildSelector() {
        val row = selectorRow ?: return
        row.removeAllViews()
        groups.forEachIndexed { i, g ->
            row.addView(TextView(this).apply {
                text = if (i == 0) "T" else "T${i + 1}"
                textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(colorOf(g))
                    setStroke(if (i == selectedGroup) dp(3) else dp(1), Color.WHITE)
                }
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
                setOnClickListener { selectedGroup = i; rebuildSelector() }
            })
        }
        if (groups.size < MAX_GROUPS) {
            row.addView(TextView(this).apply {
                text = "+"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(0xFF455A9E.toInt()); setStroke(dp(1), Color.WHITE)
                }
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
                setOnClickListener { addGroup() }
            })
        }
    }

    private fun addGroup() {
        if (groups.size >= MAX_GROUPS) {
            Toast.makeText(this, "أقصى عدد من T هو $MAX_GROUPS", Toast.LENGTH_SHORT).show()
            return
        }
        val (nx, ny) = defaultTPos(groups.size)
        createGroup(nx, ny, (groups.maxOfOrNull { it.colorIdx } ?: -1) + 1)
        selectedGroup = groups.size - 1
        relabelAll()
        rebuildSelector()
        persistGroups()
        Toast.makeText(this, "تمت إضافة T جديد. حرّكه وأضف له نسخًا", Toast.LENGTH_LONG).show()
    }

    private fun deleteSelectedGroup() {
        if (groups.size <= 1) {
            Toast.makeText(this, "لازم يبقى T واحد على الأقل", Toast.LENGTH_SHORT).show()
            return
        }
        val g = groups.getOrNull(selectedGroup) ?: return
        clearGroupCopies(g)
        g.tView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        groups.remove(g)
        selectedGroup = 0
        relabelAll()
        rebuildSelector()
        persistGroups()
        Toast.makeText(this, "تم حذف الـ T ونسخه", Toast.LENGTH_SHORT).show()
    }

    // ---- Press modes ----
    private fun pressLabel() = when (pressMode) {
        1 -> "نوع الضغط: مطوّل"
        2 -> "نوع الضغط: متكرر سريع"
        else -> "نوع الضغط: نقرة"
    }

    private fun togetherLabel() = if (together) "التزامن: معًا في نفس اللحظة" else "التزامن: تتابع سريع"

    private fun holdMs() = when (pressMode) { 1 -> 1200L; 2 -> 30L; else -> 50L }

    private fun saveModes() {
        getSharedPreferences("tp", 0).edit().putInt("press_mode", pressMode).putBoolean("together", together).apply()
    }

    // Pressing a T: one tap / one long press, or (fast-repeat mode) start and stop repeating.
    private fun onTPressed(g: Group) {
        if (repeating) { stopRepeating(); return }
        if (busy) return
        if (TouchAccessibilityService.instance == null) {
            Toast.makeText(this, "فعّل خدمة إمكانية الوصول الخاصة بـ TouchPilot أولاً", Toast.LENGTH_LONG).show()
            return
        }
        if (tCenter(g) == null) return
        setMenuOpen(false)
        busy = true
        // Every T and copy ignores touches while the gesture runs, so it reaches the app underneath.
        passThrough = true
        refreshTouchability()
        if (pressMode == 2) {
            repeating = true
            logoView?.invalidate()
            Toast.makeText(this, "بدأ التكرار السريع. اضغط الدائرة الحمراء للإيقاف", Toast.LENGTH_LONG).show()
        }
        // Give the window flag change a moment to take effect before the first gesture.
        handler.postDelayed({ runRound(g) }, 80L)
    }

    private fun runRound(g: Group) {
        dispatchRound(g, holdMs()) { ok ->
            if (!ok) {
                repeating = false
                logoView?.invalidate()
                finishPress()
                Toast.makeText(this, "تعذر إرسال اللمسات. تأكد من تفعيل خدمة TouchPilot.", Toast.LENGTH_LONG).show()
            } else if (repeating) {
                handler.post { runRound(g) }
            } else {
                finishPress()
            }
        }
    }

    private fun finishPress() {
        busy = false
        passThrough = false
        refreshTouchability()
    }

    private fun stopRepeating() {
        if (!repeating) return
        repeating = false
        logoView?.invalidate()
        Toast.makeText(this, "تم إيقاف التكرار", Toast.LENGTH_SHORT).show()
    }

    // One round = a touch at the group's T plus a touch at each of its copies.
    private fun dispatchRound(g: Group, duration: Long, onDone: (Boolean) -> Unit) {
        val accessibility = TouchAccessibilityService.instance
        val main = tCenter(g)
        if (accessibility == null || main == null) { onDone(false); return }
        val points = listOf(main) + g.coords.toList()
        var finished = false
        val finish: (Boolean) -> Unit = { ok ->
            if (!finished) { finished = true; onDone(ok) }
        }
        // Safety net in case the system never reports the gesture result.
        val worst = if (together) duration else duration * points.size
        handler.postDelayed({ finish(true) }, worst + 1500L)
        if (together) {
            // One gesture with one stroke per point, all starting at the same instant.
            val ok = accessibility.dispatchTogether(points, duration) { finish(true) }
            if (!ok) finish(false)
        } else {
            // Quick one-after-another taps, each sent as soon as the previous one ends.
            fun step(i: Int) {
                if (i >= points.size) { finish(true); return }
                val ok = accessibility.dispatchTogether(listOf(points[i]), duration) { step(i + 1) }
                if (!ok) finish(false)
            }
            step(0)
        }
    }

    private fun clearGroupCopies(g: Group) {
        g.views.forEach { try { windowManager.removeView(it) } catch (_: Exception) { } }
        g.views.clear()
        g.coords.clear()
    }

    private fun clearCopies() {
        val g = groups.getOrNull(selectedGroup) ?: return
        clearGroupCopies(g)
        persistGroups()
        Toast.makeText(this, "تم حذف نسخ الـ T المختار", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        val prefs = getSharedPreferences("tp", 0)
        pressMode = prefs.getInt("press_mode", 0).coerceIn(0, 2)
        together = prefs.getBoolean("together", true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_PROJECTION -> startProjection(intent)
            ACTION_SHOW_PANEL -> showPanel()
            ACTION_REFRESH_POINTS -> refreshPointViews()
            ACTION_RESTORE_OVERLAYS -> restoreOverlays()
        }
        return START_STICKY
    }

    private fun startProjection(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") (intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
        if (resultCode != Activity.RESULT_OK || data == null) return
        startForeground(notificationId, buildNotification(), if (Build.VERSION.SDK_INT >= 29) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection?.stop()
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                releaseCaptureResources()
                projection = null
            }
        }, handler)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("touchpilot_capture", "TouchPilot screen capture", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "touchpilot_capture").setContentTitle("TouchPilot").setContentText("إذن التقاط الشاشة نشط").setSmallIcon(android.R.drawable.ic_menu_camera).setContentIntent(pending).build()
        else Notification.Builder(this).setContentTitle("TouchPilot").setContentText("إذن التقاط الشاشة نشط").setSmallIcon(android.R.drawable.ic_menu_camera).build()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    // NOT_FOCUSABLE: the overlay must not steal focus from the target app.
    // NOT_TOUCH_MODAL: touches outside the overlay must reach the app behind it.
    private fun baseFlags() = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private fun overlayParams(x: Int, y: Int, touchable: Boolean = true): WindowManager.LayoutParams {
        var flags = baseFlags()
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y; alpha = 0.75f
            // Without this, on notched/punch-hole screens the window is pushed below the cutout,
            // so the chip is drawn lower than the coordinates we send to dispatchGesture.
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    // Real display size (including system bars) so the screenshot, the saved normalized
    // points and the gesture coordinates all use the same reference.
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = windowManager.maximumWindowMetrics.bounds
            return b.width() to b.height()
        }
        val m = android.util.DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    private fun cleanOldCaptures() {
        getExternalFilesDir(null)?.listFiles { f -> f.name.startsWith("capture-") && f.name.endsWith(".png") }
            ?.forEach { try { it.delete() } catch (_: Exception) { } }
    }

    private fun chip(label: String, color: Int) = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.WHITE) }
    }

    private fun pointChip(label: String, color: Int) = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        minWidth = dp(44); minHeight = dp(44)
        background = GradientDrawable().apply { setColor(color); shape = GradientDrawable.OVAL; setStroke(dp(1), Color.WHITE) }
    }

    private fun styleButton(view: TextView, color: Int) {
        view.apply {
            textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minHeight = dp(44); minWidth = dp(190)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }
            isClickable = true
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        }
    }

    private fun setOverlaysHidden(hidden: Boolean) {
        // alpha instead of INVISIBLE: the overlay windows stay alive, which Android requires
        // for TouchPilot to be allowed to open the editor from the background.
        overlaysHidden = hidden
        allOverlays().forEach { it.alpha = if (hidden) 0f else 1f }
        // Invisible windows must also be untouchable, otherwise they swallow taps meant for
        // the point editor (and the hidden chips could be dragged by accident).
        refreshTouchability()
    }

    private fun setNotTouchable(view: View, notTouchable: Boolean) {
        val p = view.layoutParams as? WindowManager.LayoutParams ?: return
        val flags = baseFlags() or (if (notTouchable) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
        if (p.flags == flags) return
        p.flags = flags
        try { windowManager.updateViewLayout(view, p) } catch (_: Exception) { }
    }

    private fun refreshTouchability() {
        panel?.let { setNotTouchable(it, overlaysHidden) }
        val block = overlaysHidden || passThrough
        chipViews().forEach { setNotTouchable(it, block) }
    }

    private var menu: LinearLayout? = null

    private fun setMenuOpen(open: Boolean) {
        menu?.visibility = if (open) View.VISIBLE else View.GONE
        val box = panel ?: return
        try { windowManager.updateViewLayout(box, box.layoutParams) } catch (_: Exception) { }
    }

    private fun toggleMenu() = setMenuOpen(menu?.visibility != View.VISIBLE)

    // Small round logo: purple disc, white ring, centre dot (touch-target look).
    private inner class LogoView : View(this@TouchService) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(dp(48), dp(48))
        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f; val r = width / 2f - dp(2)
            p.style = Paint.Style.FILL; p.color = if (repeating) 0xE6C62828.toInt() else 0xE66750A4.toInt(); c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = Color.WHITE
            c.drawCircle(cx, cy, r, p)
            c.drawCircle(cx, cy, r * 0.55f, p)
            p.style = Paint.Style.FILL; c.drawCircle(cx, cy, r * 0.2f, p)
        }
    }

    private fun showPanel() {
        if (panel != null) { panel?.visibility = View.VISIBLE; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val logo = LogoView()
        logoView = logo
        box.addView(logo, LinearLayout.LayoutParams(-2, -2))

        val menuBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply { setColor(0xEE172033.toInt()); cornerRadius = dp(14).toFloat() }
            visibility = View.GONE
        }
        menu = menuBox
        box.addView(menuBox, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })

        menuBox.addView(TextView(this).apply {
            text = "اختر T (الإضافات تخص T المختار)"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        val selector = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        selectorRow = selector
        menuBox.addView(selector)
        addPanelAction(menuBox, "التقاط صورة وتحديد النقاط") { setMenuOpen(false); captureGroup = selectedGroup; captureScreen() }
        // "تاتش": asks how many copies (1..6) to add, then drops that many numbered points.
        val countBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE
            setPadding(0, dp(6), 0, dp(2))
        }
        countBox.addView(TextView(this).apply {
            text = "كم نسخة تريد؟"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        val countRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (n in 1..6) {
            countRow.addView(TextView(this).apply {
                text = n.toString(); textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE64A79.toInt()) }
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) }
                setOnClickListener { countBox.visibility = View.GONE; addTouchCopies(n) }
            })
        }
        countBox.addView(countRow)
        addPanelAction(menuBox, "إضافة نسخ للـ T المختار", 0xFFE64A79.toInt()) {
            countBox.visibility = if (countBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        menuBox.addView(countBox)
        val modeAction = TextView(this).apply {
            text = pressLabel()
            styleButton(this, 0xFF37474F.toInt())
            setOnClickListener {
                pressMode = (pressMode + 1) % 3
                saveModes()
                text = pressLabel()
                Toast.makeText(this@TouchService, pressLabel(), Toast.LENGTH_SHORT).show()
            }
        }
        menuBox.addView(modeAction)
        val syncAction = TextView(this).apply {
            text = togetherLabel()
            styleButton(this, 0xFF00695C.toInt())
            setOnClickListener {
                together = !together
                saveModes()
                text = togetherLabel()
                Toast.makeText(this@TouchService, togetherLabel(), Toast.LENGTH_SHORT).show()
            }
        }
        menuBox.addView(syncAction)
        addPanelAction(menuBox, "حذف نسخ الـ T المختار", 0xFF8E24AA.toInt()) { setMenuOpen(false); clearCopies() }
        addPanelAction(menuBox, "حذف الـ T المختار ونسخه", 0xFFAD1457.toInt()) { setMenuOpen(false); deleteSelectedGroup() }
        addPanelAction(menuBox, "إغلاق اللوحة", 0xFF6D4C41.toInt()) { stopSelf() }
        panel = box
        windowManager.addView(box, overlayParams(24, 170))
        logo.setOnTouchListener(dragListener(box) { if (repeating) stopRepeating() else toggleMenu() })
        loadGroups()
    }

    private fun addPanelAction(parent: LinearLayout, title: String, color: Int = 0xFF455A9E.toInt(), action: () -> Unit): TextView {
        val button = TextView(this).apply {
            text = title
            styleButton(this, color)
            setOnClickListener { action() }
        }
        parent.addView(button)
        return button
    }

    private fun dragListener(view: View, onDragEnd: () -> Unit = {}, onTap: () -> Unit): View.OnTouchListener {
        var downX = 0f; var downY = 0f; var originX = 0; var originY = 0; var dragged = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        return View.OnTouchListener { _, event ->
            val params = view.layoutParams as WindowManager.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; originX = params.x; originY = params.y; dragged = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX; val dy = event.rawY - downY
                    if (!dragged && kotlin.math.hypot(dx, dy) > slop) dragged = true
                    if (dragged) {
                        params.x = originX + dx.toInt()
                        params.y = originY + dy.toInt()
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!dragged) onTap() else onDragEnd(); true }
                else -> true
            }
        }
    }

    private fun addTouchCopies(count: Int) {
        val g = groups.getOrNull(selectedGroup) ?: return
        val center = tCenter(g) ?: return
        val (screenW, screenH) = screenSize()
        val gap = dp(64).toFloat()
        val margin = dp(30).toFloat()
        // Copies fan out next to their own T, towards the middle of the screen.
        val dir = if (center.first < screenW / 2f) 1f else -1f
        for (i in 0 until count) {
            // Each new copy gets its own free slot (3 per row), so copies added later never
            // land on top of copies that already exist.
            val slot = g.coords.size
            val x = (center.first + dir * gap * ((slot % 3) + 1)).coerceIn(margin, screenW - margin)
            val y = (center.second + gap * (slot / 3)).coerceIn(margin, screenH - margin)
            addCopy(g, x, y)
        }
        persistGroups()
        Toast.makeText(this, "تمت إضافة $count نسخة", Toast.LENGTH_SHORT).show()
    }

    private fun addCopy(g: Group, x: Float, y: Float) {
        g.coords.add(x to y)
        val view = pointChip("${groups.indexOf(g) + 1}.${g.coords.size}", colorOf(g))
        g.views.add(view)
        view.alpha = if (overlaysHidden) 0f else 1f
        windowManager.addView(view, overlayParams(max(0, x.toInt() - dp(22)), max(0, y.toInt() - dp(22)), !overlaysHidden && !passThrough))
        view.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = v.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        p.x=ox+(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt()
                        windowManager.updateViewLayout(v,p)
                        val idx=g.views.indexOf(v)
                        if (idx>=0) g.coords[idx]=p.x+v.width/2f to p.y+v.height/2f
                        return true
                    }
                    MotionEvent.ACTION_UP -> { persistGroups(); return true }
                }
                return false
            }
        })
    }

    // Older versions saved one T position plus a flat list of points. Those become the first group.
    private fun loadPointsInto(g: Group) {
        val raw = getSharedPreferences("tp", 0).getString("points", null) ?: return
        try {
            val array = JSONArray(raw)
            val (screenW, screenH) = screenSize()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                addCopy(g, item.getDouble("x").toFloat() * screenW, item.getDouble("y").toFloat() * screenH)
            }
        } catch (_: Exception) { }
    }

    private fun loadGroups() {
        val prefs = getSharedPreferences("tp", 0)
        val (screenW, screenH) = screenSize()
        val raw = prefs.getString("groups", null)
        if (raw != null) {
            try {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    val (dx, dy) = defaultTPos(i)
                    val g = createGroup(
                        o.optDouble("tx", dx.toDouble()).toFloat(),
                        o.optDouble("ty", dy.toDouble()).toFloat(),
                        o.optInt("c", i)
                    )
                    val copies = o.optJSONArray("copies")
                    if (copies != null) {
                        for (k in 0 until copies.length()) {
                            val item = copies.getJSONObject(k)
                            addCopy(g, item.getDouble("x").toFloat() * screenW, item.getDouble("y").toFloat() * screenH)
                        }
                    }
                }
            } catch (_: Exception) { }
        }
        if (groups.isEmpty()) {
            val g = createGroup(prefs.getFloat("t_x", 0.8f), prefs.getFloat("t_y", 0.5f), 0)
            loadPointsInto(g)
            persistGroups()
        }
        selectedGroup = 0
        relabelAll()
        rebuildSelector()
    }

    // The screenshot editor saves its points under "points": they become the copies of the T that
    // was selected when the screenshot was started.
    private fun refreshPointViews() {
        panel?.visibility = View.VISIBLE
        val g = groups.getOrNull(captureGroup) ?: groups.firstOrNull()
        if (g != null) {
            clearGroupCopies(g)
            loadPointsInto(g)
            persistGroups()
        }
        restoreOverlays()
    }

    private fun persistGroups() {
        val (screenW, screenH) = screenSize()
        val array = JSONArray()
        groups.forEach { g ->
            val o = org.json.JSONObject()
            val c = tCenter(g)
            if (c != null) {
                o.put("tx", (c.first / screenW).toDouble())
                o.put("ty", (c.second / screenH).toDouble())
            }
            o.put("c", g.colorIdx)
            val copies = JSONArray()
            g.coords.forEach { (x, y) ->
                copies.put(org.json.JSONObject().put("x", (x / screenW).toDouble()).put("y", (y / screenH).toDouble()))
            }
            o.put("copies", copies)
            array.put(o)
        }
        getSharedPreferences("tp", 0).edit().putString("groups", array.toString()).apply()
    }

    private fun captureScreen() {
        if (projection == null) {
            Toast.makeText(this, "فعّل التقاط الشاشة من التطبيق الرئيسي أولاً", Toast.LENGTH_LONG).show()
            return
        }
        // Hide controls so the screenshot is a clean view of the target app.
        setOverlaysHidden(true)
        handler.postDelayed({
            try {
                val dm = resources.displayMetrics
                val (screenW, screenH) = screenSize()
                try { imageReader?.close() } catch (_: Exception) { }
                imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
                if (virtualDisplay == null) {
                    virtualDisplay = projection?.createVirtualDisplay(
                        "TouchPilotCapture", screenW, screenH, dm.densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, handler
                    )
                } else {
                    virtualDisplay?.setSurface(imageReader?.surface)
                }
                imageReader?.setOnImageAvailableListener({ reader ->
                    val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                    try {
                        val plane = image.planes[0]
                        val pixelStride = plane.pixelStride
                        val rowStride = plane.rowStride
                        val rowPadding = rowStride - pixelStride * image.width
                        val padded = Bitmap.createBitmap(
                            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
                        )
                        padded.copyPixelsFromBuffer(plane.buffer)
                        val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
                        padded.recycle()
                        cleanOldCaptures()
                        val file = File(getExternalFilesDir(null), "capture-${System.currentTimeMillis()}.png")
                        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        bitmap.recycle()
                        virtualDisplay?.setSurface(null)
                        try { imageReader?.close() } catch (_: Exception) { }
                        imageReader = null
                        val editor = Intent(this, PointEditorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        editor.putExtra("image_path", file.absolutePath)
                        try {
                            startActivity(editor)
                        } catch (e: Exception) {
                            Toast.makeText(this, "تعذر فتح المحرر: ${e.message}", Toast.LENGTH_LONG).show()
                            restoreOverlays()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this, "فشل حفظ الصورة: ${e.message}", Toast.LENGTH_LONG).show()
                        detachCaptureReader()
                        restoreOverlays()
                    } finally { image.close() }
                }, handler)
                handler.postDelayed({
                    if (imageReader != null) {
                        Toast.makeText(this, "لم تصل صورة من النظام. جرّب مرة أخرى.", Toast.LENGTH_LONG).show()
                        detachCaptureReader(); restoreOverlays()
                    }
                }, 2500)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر التقاط الشاشة: ${e.message}", Toast.LENGTH_LONG).show()
                detachCaptureReader(); restoreOverlays()
            }
        }, 250)
    }

    private fun restoreOverlays() {
        setOverlaysHidden(false)
        allOverlays().forEach { it.visibility = View.VISIBLE }
    }

    private fun detachCaptureReader() {
        try { virtualDisplay?.setSurface(null) } catch (_: Exception) { }
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
    }

    private fun releaseCaptureResources() {
        detachCaptureReader()
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        repeating = false
        busy = false
        releaseCaptureResources()
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        allOverlays().forEach { try { windowManager.removeView(it) } catch (_: Exception) { } }
        groups.clear()
        panel = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        private const val MAX_GROUPS = 5
        private val GROUP_COLORS = intArrayOf(
            0xFFE64A79.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFB8C00.toInt(), 0xFF8E24AA.toInt(), 0xFF00ACC1.toInt()
        )
        const val ACTION_START_PROJECTION = "com.touchpilot.START_PROJECTION"
        const val ACTION_SHOW_PANEL = "com.touchpilot.SHOW_PANEL"
        const val ACTION_REFRESH_POINTS = "com.touchpilot.REFRESH_POINTS"
        const val ACTION_RESTORE_OVERLAYS = "com.touchpilot.RESTORE_OVERLAYS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
    }
}
